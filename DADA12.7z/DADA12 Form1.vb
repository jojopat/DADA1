﻿'Directional Antenna Deployment Assitant 1 - calculate angle And distant between two ham station

'BEFORE USE : download open Government data from this link 

'https://data.go.th/th/dataset/item_c6d42e1b-3219-47e1-b6b7-dfe914f27910

'Open the Excel file And save it As Comma Separated Value (.CSV) file under the name
'OpenGovernmentLatLongTambon.csv
'Place this CSV In the same folder As DADA exe
'Run DADA exe, the app will read CSV into memory And ready To use
'Type in your home QTH into the textbox "จตุจั" And press enter. Chatuchak coordinate will appear
'Press F8 To Set Chatuchak As your home QTH
'Type in any tambon Or ampur in part Or whole eg. "นครป" then Enter button to get Nakornpathom
'with angle And air displacement between Chatuchak And Nakornpathom.

'Contact info : Thai ham : E25VBE facebook : Pat Jojo Sadavongvivad

'Development History Of DADA - Directional Antenna Deployment Assistant

'First idea : Feb 2009, when I first acquire beginner ham operator license And E22JNE callsign.
'Right after decided to install directional antenna multi-beam 2x2 192E from ClubStationThai
'antenna maker. While waiting for tower And antenna installation, I started to think further
'of how to effectively use it. Then wrote Visual Foxpro code to create maxtrix table of every
'district in Thailand by taking the coordinate of every district office to to create 

'1. Distance matrix
'2. Angle matrix

'Then distribute the angle matrix in JPG for A4 And A0 paper format through ClubStationThai
'antenna manufacturer by HS1BFR Prasit Sottipattanapong.

'Later in 2019, while reading this news of how heavily calculation ham operator has to perform
'to calculate the angle to rotate the antenna in order to communicate with aboard HTMS
'Chakrinarubet while operating HS10KING/MM that I decide to write this application but cannot
'distribute due to the coordinate data Is a copyrighted dataset of commercial organization.
'Just early July 2023 that E20FWF warned me about expired license will lead to big fine after
'all ham gears turned illegal. So I rush to renew my license to receive the New callsign
'E25VBE. Then restart ham activity And reconnect all ham gears. Then start to think seriously
'of how to distribute this piece of code for the use of others. And since I am RAST lifetime
'member, I brought this idea to discuss with E20EHQ at RAST And he's very much happy about
'the idea. After that, while googling around, I found the Open Government Data from this
'website :

'https://data.go.th/th/dataset/item_c6d42e1b-3219-47e1-b6b7-dfe914f27910

'It's Lat/Long data of every tambon and ampur in Thailand as Open Government Data where everyone
'can download and free to use. So I begin to fix the code to utilize this open Government dataset.
'Then test it against the angle and distant matrix created back in 2009. Testing the result of new
'dataset against 2009 matrix has an average of only 0.2% deviation from the previous data so it is
'very acceptable. Sharpest directional antenna I know is multi-beam 2x2 192E only give 30 degrees
'half-power beam-width. And 13 elements yagi-uda antenna has 60 degrees half-power beam-width so
'0.2% deviation in the angle is very much acceptable with this dataset.

'The main part Of the app To calculate distance And angle between two stations has been done. Next
'Step Of the development Is To study To prepare some hardware To Interface To antenna rotator Like
'KenPro Or other brands To integrate DADA With CAT-protocol supported tranceivers In order To Do
'final adjustment Of the direction To find peak signal strength. Or To add some other features in
'the future.

'Feel free To further develop this code For the advancement Of the hams. Kindly keep Me inform so
'To spread such happiness around ^_^

'E25VBE Or Pat Jojo Sadavongvivad on facebook.com

'Without kind words from HS1BFR And HS1KBG On 144.100 MHz ham band back In 2009 I would Not have
'started all this activity. They show And pass To Me the spirits Of the hams And also continuously
'empower Me To Continue To develop over the years. All thanks As a result Of the usefulness Of
'DADA Is what I learn from both of them.
'
'DADA11 Update 2023/10/26 add Maidenhead grid locator and the source code was lost due to older copy of folder synced to Google Drive
'DADA11 Update 2024/5/5 Add Maidenhead grid locator and nearest district locator to grid center
'DADA11 Update 2024/5/6 List province, districts and subdistricts in grid
'
' To-do next:
'
' DADA2 : Directional Antenna Deployment Automation
' - make bluetooth board with 3 relays 2-channel 10-bit ADC to read rotor position
' - add code to automate rotator control to target angle
'
' DADA3 : Directional Antenna Detection Assistant
' - communicate with bluetooth CAT or CIV port
' - read Received Signal Strength Index from transceiver through CAT or CIV commands
' - during first few QSOs slowly adjust the antenna angle to find position with highest S-meter
'
' DADA31
' - take QSO audio signal to analyze using ML to interpret QRK1 to 5
' - adjust antenna angle so to have highest QRK or least Signal-to-Noise Ratio.
'
'




Imports System.IO
Imports System.Text.RegularExpressions


Public Class Form1
    ' 2 available value : 1 OpenGovernmentLatLongTambon and 2 UTM
    Public searchMode As String
    Public searchText As String     ' text to search for / ข้อความที่ต้องการค้นหา
    Public csvFilePath As String = ".\OpenGovernmentLatLongTambon.csv" ' path to data file
    Public csvData As New List(Of String())

    ' Declare to handle database connection
    Public dBaseConnection As New System.Data.OleDb.OleDbConnection

    ' fsHomeX & fsHomeY is float single precision Home QTH Lat/Long or UTM
    Public fsHomeX, fsHomeY, fDestX, fDestY, fDeltaX, fDeltaY As Single
    Public strHomeDist As String

    Public pubmaidengrid As String
    Public pubmaidenLat, pubmaidenLon As Single ' Lat/Lon of center of grid
    Public pubmaidenLat1, pubmaidenLon1, pubmaidenLat2, pubmaidenLon2 As Single ' Upper left-Lower right of grid

    ' Nearest place to center of grid
    Public nrstSubdistrict, nrstDistrict, nrstProvince As String

    ' fsCompass is electronic compass report angle
    ' fsHeading is routing heading angle reported from GPS
    Public fsCompass, fsHeading As Single
    Public fsAngle, fsDistance As Single

    ' iTargetAngle is target antenna angle pointing to destination location
    Public iTargetAngle As Integer
    Public sTargetPlaceName As String

    ' Return value of a location from OpenGovernmentLatLongTambon
    Public strLat, strLong, strSubdistrict, strDistrict, strProvince As String
    Public ConnectDB As String



    ' Convert Maidenhead grid to Latitude & Longitude
    Function Maidenhead2Latlong(strInput As String) As String
        ' Maidenhead grid locator validation
        'If Not Regex.IsMatch(strInput, "^[A-Ra-r]{2}[0-9]{2}[A-Za-z]{2}$") Then
        '  Return "input not Maidenhead format"
        'End If
        pubmaidengrid = strInput
        Dim maiden = strInput.ToLower()
        Dim lon As Double = 20 * (AscW(maiden(0)) - 97) + 2 * (AscW(maiden(2)) - 48)
        Dim lat As Double = 10 * (AscW(maiden(1)) - 97) + AscW(maiden(3)) - 48
        lon += (AscW(maiden(4)) - 97) / 12
        lat += (AscW(maiden(5)) - 97) / 24

        lon -= 180 : lat -= 90
        pubmaidenLon1 = lon : pubmaidenLat1 = lat ' Upper left corner of this grid
        lon += 1 / 24 : lat += 1 / 48   ' adjust to center of grid
        pubmaidenLon2 = lon + (1 / 24) : pubmaidenLat2 = lat + (1 / 48) ' lower right corner of grid
        lon = Math.Round(1000 * lon) / 1000 : lat = Math.Round(1000 * lat) / 1000

        pubmaidenLat = lat : pubmaidenLon = lon
        Return lat.ToString & "," & lon.ToString

    End Function



    ' Convert from Latitude & Longitude to Maidenhead grid
    Function LatLong2Maidenhead(lat As Single, lon As Single) As String
        lon += 180 : lat += 90
        Dim field_lon = Math.Floor(lon / 20)
        Dim field_lat = Math.Floor(lat / 10)

        Dim maiden = ChrW(65 + field_lon) + ChrW(65 + field_lat)
        Dim square_lon = Math.Floor((lon - 20 * field_lon) / 2)
        Dim square_lat = Math.Floor(lat - 10 * field_lat)
        maiden += square_lon.ToString() + square_lat.ToString()
        Dim subsquare_lon = Math.Floor(12 * (lon - 20 * field_lon - 2 * square_lon))
        Dim subsquare_lat = Math.Floor(24 * (lat - 10 * field_lat - square_lat))
        maiden += ChrW(97 + subsquare_lon) & ChrW(97 + subsquare_lat)
        Return maiden
    End Function



    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ConnectDB = "CSV"
        searchMode = "OpenGovernmentLatLongTambon"

        Log("Initializing Directional Antenna Deployment Assistant...")

        'Me.Text = "Directional Antenna Deployment Assistant 1.0 -- F8-Set MyQTH         F9-Set antenna angle"

        If ConnectDB = "CSV" Then
            ' Verify if coordinate data file exist / ตรวจสอบว่าไฟล์ข้อมูลพิกัดตำบล-อำเภอเป็น CSV มีอยู่หรือไม่
            If Not File.Exists(csvFilePath) Then
                MessageBox.Show("ไม่พบไฟล์ / not found OpenGovernmentLatLongTambon.csv, exit app.")
                Return
            End If

            ' Read coordinate data from CSV file into array
            ' อ่านข้อมูลจากไฟล์ CSV และเก็บในรูปแบบ array

            Log("  reading " & csvFilePath)
            Using reader As New StreamReader(csvFilePath)
                While Not reader.EndOfStream
                    Dim line As String = reader.ReadLine()
                    Dim values As String() = line.Split(","c) ' แยกข้อมูลโดยใช้ "," เป็นตัวแยก
                    csvData.Add(values)
                End While
            End Using
            Log("      done and is ready to run.")
            Log("Enter Maidenhead grid locator or part of province, district or subdistrict.  Eg. บางกอกน or OK03gt")
            Log("Press F8 to set last location as your QTH. ? for help.")
        End If


        If ConnectDB = "ampur.dbf" Then
            Try
                Dim tb As DataTable
                tb = getdBasetable("select * from ampur;")
                DBFDataGrid.DataSource = tb
                TextBox1.Select()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If


        Me.Top = 52 : Me.Left = 52
        DBFDataGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnMode.DisplayedCells
        Timer1.Interval = 1000
        Timer1.Enabled = True
        fsHomeX = 0
        fsHomeY = 0
        lblMyPlace.AutoSize = True : lblMyPlace.Width = 20
        lblMyPlace.Text = "My QTH: Unset"
        lblSearchStatus.Text = "..."
        lblSearchStatus.Refresh()
        lblDestination.Text = "คู่สถานี / Destination :"
        lblDestUTM.Text = "Unset"
        lblDistance.Text = "ระยะทาง / Distance :"
        lblUTMY.AutoSize = True : lblUTMY.Width = 28
        lblUTMY.Text = "Home LatLong :"
        lblHeading.AutoSize = True : lblHeading.Width = 30
        lblCompass.AutoSize = True : lblCompass.Width = 30
        lblTargetAngle.Text = "Target Antenna Angle :"
        lblCurAngle.Text = "Current Antenna Angle :"

        TextBox1.Select()   ' Set focus


        Me.KeyPreview = True
        AddHandler Me.KeyDown, AddressOf KeyDownHandler
        AddHandler Me.KeyUp, AddressOf KeyUpHandler

    End Sub

    Private Sub LblFunctionKey_Click(sender As Object, e As EventArgs) Handles lblFunctionKey.Click

    End Sub

    Public Function getdBasetable(ByVal SqlString As String) As DataTable
        Dim ReturnableTable As New DataTable
        Try
            OpendBConnection()
            Dim SelectCommand As New System.Data.OleDb.OleDbCommand(SqlString, dBaseConnection)
            Dim TableAdapter As System.Data.OleDb.OleDbDataAdapter = New System.Data.OleDb.OleDbDataAdapter
            TableAdapter.SelectCommand = SelectCommand
            TableAdapter.Fill(ReturnableTable)
            Return ReturnableTable
        Catch ex As Exception
            MsgBox(ex.Message & vbCrLf & SqlString, 16, "Error")
            End
        End Try
        Return ReturnableTable
    End Function

    Public Sub OpendBConnection()
        Try
            Dim ConnectionString As String
            ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=.\;Extended Properties=dBase IV"
            dBaseConnection = New System.Data.OleDb.OleDbConnection(ConnectionString)
            If dBaseConnection.State = 0 Then dBaseConnection.Open()
        Catch ex As Exception
            MsgBox(ex.Message, 16, "Error")
        End Try
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        'Label1.Text = TextBox1.Text
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress

        If e.KeyChar = Chr(13) Then
            Dim temp As Integer = 0
            Dim j As Integer = 5 ' Search in District name field
            Dim sTmp As String
            Dim iPos As Integer
            Dim sSearchFor, sCellToSearch As String

            If TextBox1.Text = "?" Then ' request for help
                TextBox1.Text = ""
                Log("")
                Log("DADA11 Directional Antenna Deployment Assistant 1.1 Help")
                Log("--------------------------------------------------------")
                Log("This app help ham with directional antenna calculating angle & distance between two radio stations.")
                Log("Enter any text to free-text-search subdistrict, district or province name from OpenGovernmentData")
                Log("Then press F8 to set last position found to mark your station location.")
                Log("After that enter any place in Thailand, the app will calculate angle from yours to that place.")
                Log("Enter ลอง will stop at first คลอง found, you may use [อ. ลอง] (notice space between อ. and ลอง).")
                Log("Some samples [เมืองระยอง] [อ. ปะทิว] [จ. สตูล] [ต. นาเกลือ]")

                ' Validate Maidenhead grid locator
            ElseIf Regex.IsMatch(TextBox1.Text, "^[A-Ra-r]{2}[0-9]{2}[A-Za-z]{2}$") Then
                Dim maiden = Maidenhead2Latlong(TextBox1.Text)
                SearchOpenGovernmentforNearestLatLong(pubmaidenLat, pubmaidenLon) ' Locate nearest Ampur/Tambon
                FindOpenGovernmentInLatLon(pubmaidenLon1, pubmaidenLat1, pubmaidenLon2, pubmaidenLat2)
                'Log("Maidenhead grid " & TextBox1.Text & " pointing to " & maiden & " " & nrstProvince & " " & nrstDistrict & " " & nrstSubdistrict)

                sTargetPlaceName = Trim(pubmaidengrid) & " " & Trim(nrstSubdistrict) & " " & Trim(nrstDistrict) & " " & Trim(nrstProvince)
                lblDestination.Text = "To :" & Trim(sTargetPlaceName)
                lblDestination.Refresh()

                lblDestUTM.Text = Trim(pubmaidenLat) & " " & Trim(pubmaidenLon) 'LatLong2Maidenhead(Val(strLat), Val(strLong))      ' UTMX
                lblDestUTM.Refresh()

                ' calculate angle
                fDestX = Val(pubmaidenLon)         ' Destination Longitude
                fDestY = Val(pubmaidenLat)          ' Destination Latitude
                fDeltaX = fDestX - fsHomeX
                fDeltaY = fDestY - fsHomeY

                'fsDistance = Math.Sqrt(((fDestX - fsHomeX) ^ 2 + (fDestY - fsHomeY) ^ 2)) / 10                  

                fsAngle = (Math.Atan2(fDeltaY, fDeltaX)) * (180 / Math.PI)
                If fsAngle >= 0 And fsAngle <= 90 Then
                    iTargetAngle = 90 - fsAngle
                ElseIf fsAngle < 0 And fsAngle > -180 Then
                    iTargetAngle = -(fsAngle - 90)
                ElseIf fsAngle > 90 And fsAngle <= 180 Then
                    iTargetAngle = 450 - fsAngle
                End If

                ' verify heading and compass, warn if inconsistent

                ' compensate angle from heading

                ' calculate distance

                If fsHomeX <> 0 And fsHomeY <> 0 Then
                    fsDistance = CalculateDistanceLatLongKm(fsHomeY, fsHomeX, fDestY, fDestX)
                    lblDistance.Text = "Distance :" & fsDistance & " km"
                    lblDistance.Refresh()

                    Log("From : " & Trim(strHomeDist) & "->" & Trim(strSubdistrict) & " " & iTargetAngle & " degree, " & fsDistance & "km.")
                End If

                'iTargetAngle = Rnd() * 360
                lblTargetAngle.Text = "Target Angle :" & iTargetAngle.ToString

                temp = 1


            ElseIf searchMode = "OpenGovernmentLatLongTambon" Then
                SearchOpenGovernmentLatLongTambon(TextBox1.Text)

                If strLat <> "not found" Then
                    lblSearchStatus.Text = "Matched."
                    lblSearchStatus.Refresh()

                    sTargetPlaceName = Trim(strSubdistrict) & " " & Trim(strDistrict) & " " & Trim(strProvince)
                    lblDestination.Text = "To :" & sTargetPlaceName
                    lblDestination.Refresh()

                    lblDestUTM.Text = strLat & "," & strLong & " " & LatLong2Maidenhead(Val(strLat), Val(strLong))      ' UTMX
                    lblDestUTM.Refresh()


                    ' calculate angle
                    fDestX = Val(strLong)         ' Destination Longitude
                    fDestY = Val(strLat)          ' Destination Latitude
                    fDeltaX = fDestX - fsHomeX
                    fDeltaY = fDestY - fsHomeY

                    'fsDistance = Math.Sqrt(((fDestX - fsHomeX) ^ 2 + (fDestY - fsHomeY) ^ 2)) / 10                  

                    fsAngle = (Math.Atan2(fDeltaY, fDeltaX)) * (180 / Math.PI)
                    If fsAngle >= 0 And fsAngle <= 90 Then
                        iTargetAngle = 90 - fsAngle
                    ElseIf fsAngle < 0 And fsAngle > -180 Then
                        iTargetAngle = -(fsAngle - 90)
                    ElseIf fsAngle > 90 And fsAngle <= 180 Then
                        iTargetAngle = 450 - fsAngle
                    End If

                    ' verify heading and compass, warn if inconsistent

                    ' compensate angle from heading

                    ' calculate distance

                    If fsHomeX <> 0 And fsHomeY <> 0 Then
                        fsDistance = CalculateDistanceLatLongKm(fsHomeY, fsHomeX, fDestY, fDestX)
                        lblDistance.Text = "Distance :" & fsDistance & " km"
                        lblDistance.Refresh()

                        Log("From : " & Trim(strHomeDist) & "->" & Trim(lblDestination.Text) & " " & iTargetAngle & " degree, " & fsDistance & "km.")
                    End If

                    'iTargetAngle = Rnd() * 360
                    lblTargetAngle.Text = "Target Angle :" & iTargetAngle.ToString

                    temp = 1
                Else
                    lblSearchStatus.Text = "Not found"
                        lblSearchStatus.Refresh()
                    End If

                End If

                If searchMode = "UTM" Then
                    sSearchFor = TextBox1.Text
                    For i As Integer = 0 To DBFDataGrid.RowCount - 2
                        'For j As Integer = 0 To DBFDataGrid.ColumnCount - 1
                        iPos = TextBox2.Text.Length
                        iPos = If(iPos > 2000, 2000, iPos)
                        sTmp = TextBox2.Text.Substring(iPos)


                        sCellToSearch = DBFDataGrid.Rows(i).Cells(j).Value.ToString
                        Try
                            lblSearchStatus.Text = i : lblSearchStatus.Refresh()
                            If InStr(sCellToSearch, sSearchFor) > 0 Then
                                sTargetPlaceName = DBFDataGrid.Rows(i).Cells(j).Value.ToString & " " & DBFDataGrid.Rows(i).Cells(4).Value.ToString
                            lblDestination.Text = "To :" & sTargetPlaceName
                            lblDestination.Refresh()

                                ' calculate angle
                                fDestX = DBFDataGrid.Rows(i).Cells(1).Value.ToString       ' Destination UTMX
                                fDestY = DBFDataGrid.Rows(i).Cells(2).Value.ToString()     ' Destination UTMY
                                fDeltaX = fDestX - fsHomeX
                                fDeltaY = fDestY - fsHomeY
                                fsDistance = Math.Sqrt(((fDestX - fsHomeX) ^ 2 + (fDestY - fsHomeY) ^ 2)) / 100000
                                fsAngle = (Math.Atan2(fDeltaY, fDeltaX)) * (180 / Math.PI)
                                If fsAngle >= 0 And fsAngle <= 90 Then
                                    iTargetAngle = 90 - fsAngle
                                ElseIf fsAngle < 0 And fsAngle > -180 Then
                                    iTargetAngle = -(fsAngle - 90)
                                ElseIf fsAngle > 90 And fsAngle <= 180 Then
                                    iTargetAngle = 450 - fsAngle
                                End If

                                ' verify heading and compass, warn if inconsistent

                                ' compensate angle from heading

                                ' calculate distance


                                lblDistance.Text = "Distance :" & fsDistance & " km"
                                lblDistance.Refresh()

                                'iTargetAngle = Rnd() * 360
                                lblTargetAngle.Text = "Target Angle :" & iTargetAngle.ToString

                                'Label2.Text = DBFDataGrid.Rows(i).Cells(1).Value.ToString       ' UTMX
                                'Label2.Refresh()
                                'Label3.Text = DBFDataGrid.Rows(i).Cells(2).Value.ToString()     ' UTMY
                                'Label3.Refresh()


                                temp = 1
                                Exit For
                            End If
                        Catch

                        End Try
                        'Next
                    Next
                    If temp = 0 Then
                        lblDestination.Text = "Not Found"
                        iTargetAngle = -1
                    End If
                End If ' End If SearchUTM
            End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        'fsHomeX = fsHomeX + Rnd() * 50 - 25
        'fsHomeY = fsHomeY + (Rnd() * 50) - 25
        fsHeading = fsHeading + (4 * Rnd() - 2)
        Dim iDisplayHeading As Integer = If(fsHeading < 0, 360 - fsHeading, Int(fsHeading))

        If fsHeading > 360 Then fsHeading = fsHeading - 360
        If fsHeading < 0 Then fsHeading = 360 + fsHeading

        'lblUTMY.Text = "UTMY " & fsHomeY.ToString
        lblHeading.Text = "Heading " & iDisplayHeading.ToString
        lblCompass.Text = "Compass " & iDisplayHeading.ToString

    End Sub


    Private Sub KeyUpHandler(ByVal o As Object, ByVal e As KeyEventArgs)
        e.SuppressKeyPress = True

        ' Key F8 - Process set my QTH

        If e.KeyCode = Keys.F8 Then
            If iTargetAngle >= 0 Then
                fsHomeX = fDestX
                fsHomeY = fDestY
                'TextBox2.AppendText(System.DateTime.Today.ToString & " Set Current position to 47 N " & fsHomeX & " " & fsHomeY & " " & sTargetPlaceName & vbCrLf)
                'TextBox2.AppendText(System.DateTime.Today.ToString & " Set my QTH to " & sTargetPlaceName & vbCrLf)

                Log(vbCrLf & "#### Set my QTH to " & sTargetPlaceName & " ####" & vbCrLf)
                TextBox1.Text = ""
                lblUTMY.Text = strLat & "," & strLong      ' UTMX
                lblDestUTM.Refresh()
                lblMyPlace.Text = "MyQTH:" & sTargetPlaceName
                strHomeDist = strDistrict
            End If
        End If

        ' Shift-F8 to save my QTH
        If e.KeyCode = Keys.LShiftKey And Keys.F8 Then

            Log("save MyQTH " & sTargetPlaceName & "to config file.")
            ' If fsHomeX & Y already initialized, save the coordinate to file

            If fsHomeX > 0 And fsHomeY > 0 Then

                MessageBox.Show("Save HomeQTH to file not implemented yet.")

            End If

        End If


        If e.KeyCode = Keys.F9 Then
            If iTargetAngle >= 0 Then

                Log(" Rotating antenna to " & iTargetAngle & " " & sTargetPlaceName)
                TextBox1.Text = ""
                lblCurAngle.Text = "Current Antenna Angle : " & iTargetAngle

            Else

                Log("Target destination not set.")

            End If
        End If


        If e.KeyCode = Keys.F3 Then




        End If
        'TextBox2.AppendText(
        'String.Format("'{0}' '{1}' '{2}' '{3}' {4}", e.Modifiers, e.KeyValue, e.KeyData, e.KeyCode, Environment.NewLine))
    End Sub

    Private Sub KeyDownHandler(ByVal o As Object, ByVal e As KeyEventArgs)
        'e.SuppressKeyPress = True
        'TextBox2.AppendText(
        'String.Format("'{0}' '{1}' '{2}' '{3}' {4}", e.Modifiers, e.KeyValue, e.KeyData, e.KeyCode, Environment.NewLine))
    End Sub

    Private Sub SearchOpenGovernmentforNearestLatLong(lat As Single, lon As Single)
        Dim found As Boolean = False

        ' Loop for nearest point วนลูปใน array เพื่อค้นหาตำแหน่งที่ใกล้กับที่ระบุที่สุด
        Dim MD_Km As Single = 999999, curDist As Double
        Dim MD_Lat As Single, MD_Lon As Single
        Dim MD_SubDist As String, MD_Dist As String, MD_Province As String
        Dim rowIndex As Integer = 0

        For Each row In csvData
            rowIndex += 1
            'For Each cell In row
            strLat = row(10) : strLong = row(11)
            strSubdistrict = row(2) : strDistrict = row(5) : strProvince = row(8)
            curDist = CalculateDistanceLatLongKm(lat, lon, Val(strLat), Val(strLong))
            If curDist < MD_Km Then
                MD_Km = curDist : MD_SubDist = strSubdistrict : MD_Dist = strDistrict : MD_Province = strProvince
                'Debug.Print(rowIndex, MD_Dist, MD_SubDist, MD_Km)
            End If
            'Next
            If found Then Exit For
        Next
        nrstSubdistrict = MD_SubDist : nrstDistrict = MD_Dist : nrstProvince = MD_Province
        'MsgBox(MD_Km & nrstProvince & nrstDistrict & nrstSubdistrict)

    End Sub


    ' List all places in specified upper-left and lower-right lat/lon
    Private Sub FindOpenGovernmentInLatLon(Lon1 As Single, Lat1 As Single, Lon2 As Single, Lat2 As Single)
        Dim rowIndex As Integer = 0
        Dim OutputResult As String = vbCrLf

        For Each row In csvData
            rowIndex += 1

            Dim vLat = Val(row(10)), vLon = Val(row(11))
            If vLat >= Lat1 And vLon >= Lon1 And vLat <= Lat2 And vLon <= Lon2 Then
                Dim strSubdistrict = row(2), strDistrict = row(5), strProvince = row(8)
                'Dim curDist = CalculateDistanceLatLongKm(Lat1, vLon, Val(strLat), Val(strLong))
                OutputResult &= (pubmaidengrid & ": " & strProvince & " " & strDistrict & " " & strSubdistrict & vbCrLf)
                'MD_Km = curDist : MD_SubDist = strSubdistrict : MD_Dist = strDistrict : MD_Province = strProvince
                'Debug.Print(rowIndex, MD_Dist, MD_SubDist, MD_Km)
            End If

        Next

        If Len(OutputResult) > 0 Then Log(OutputResult)

    End Sub

    Private Sub SearchOpenGovernmentLatLongTambon(keyword As String)

        strLat = "not found" : strLong = strLat : strSubdistrict = strLat : strDistrict = strLat : strProvince = strLat

        searchText = TextBox1.Text.Trim()

        Dim found As Boolean = False

        ' Loop through array for matched location name วนลูปใน array เพื่อหาชื่อตามที่ระบุ
        For Each row In csvData
            For Each cell In row
                If cell.Contains(searchText) Then
                    ' ถ้าพบข้อมูลที่ต้องการ / found matched string pattern
                    'MessageBox.Show($"พบข้อมูลที่ค้นหา: {cell} LatLong:" & row(10) & "," & row(11))
                    strLat = row(10) : strLong = row(11)
                    strSubdistrict = row(2) : strDistrict = row(5) : strProvince = row(8)
                    Log("search for " & keyword & " and found " & strSubdistrict & " " & strDistrict & " " & strProvince & " at " & strLat & " / " & strLong & " " & LatLong2Maidenhead(Val(strLat), Val(strLong)))
                    found = True
                    Exit For ' หยุดการค้นหาเมื่อพบข้อมูล / exit
                End If
            Next
            If found Then Exit For
        Next

        If Not found Then
            MessageBox.Show("ไม่พบข้อมูลที่ค้นหา, location name not found.")
        End If
    End Sub


    Public Shared Function CalculateDistanceLatLongKm(
        ByVal lat1 As Double,
        ByVal lon1 As Double,
        ByVal lat2 As Double,
        ByVal lon2 As Double) As Double

        Dim earthRadius As Double = 6371 ' Radius of the Earth in kilometers

        ' Convert latitude and longitude from degrees to radians
        Dim lat1Rad As Double = ConvertToRadians(lat1)
        Dim lon1Rad As Double = ConvertToRadians(lon1)
        Dim lat2Rad As Double = ConvertToRadians(lat2)
        Dim lon2Rad As Double = ConvertToRadians(lon2)

        ' Haversine formula
        Dim dLat As Double = lat2Rad - lat1Rad
        Dim dLon As Double = lon2Rad - lon1Rad
        Dim a As Double = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                        Math.Cos(lat1Rad) * Math.Cos(lat2Rad) *
                        Math.Sin(dLon / 2) * Math.Sin(dLon / 2)
        Dim c As Double = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a))
        Dim distance As Double = earthRadius * c

        Return distance
    End Function

    Private Shared Function ConvertToRadians(ByVal degrees As Double) As Double
        Return degrees * (Math.PI / 180)
    End Function

    Private Sub Log(st As String)
        TextBox2.Text = TextBox2.Text & System.DateTime.Now.ToString & ":" & st & vbCrLf
        TextBox2.Refresh()
        ' Scroll to the last line
        TextBox2.SelectionStart = TextBox2.Text.Length
        TextBox2.ScrollToCaret()
    End Sub

End Class


