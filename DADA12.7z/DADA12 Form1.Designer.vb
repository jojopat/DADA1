﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.lblDestination = New System.Windows.Forms.Label()
        Me.lblDistance = New System.Windows.Forms.Label()
        Me.lblDestUTM = New System.Windows.Forms.Label()
        Me.lblSearchStatus = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.lblMyPlace = New System.Windows.Forms.Label()
        Me.lblUTMY = New System.Windows.Forms.Label()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lblCompass = New System.Windows.Forms.Label()
        Me.lblTargetAngle = New System.Windows.Forms.Label()
        Me.lblCurAngle = New System.Windows.Forms.Label()
        Me.lblFunctionKey = New System.Windows.Forms.Label()
        Me.DBFDataGrid = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.DBFDataGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(12, 34)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(365, 35)
        Me.TextBox1.TabIndex = 2
        '
        'lblDestination
        '
        Me.lblDestination.AutoSize = True
        Me.lblDestination.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblDestination.Location = New System.Drawing.Point(7, 74)
        Me.lblDestination.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblDestination.Name = "lblDestination"
        Me.lblDestination.Size = New System.Drawing.Size(86, 29)
        Me.lblDestination.TabIndex = 3
        Me.lblDestination.Text = "Label1"
        '
        'lblDistance
        '
        Me.lblDistance.AutoSize = True
        Me.lblDistance.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblDistance.Location = New System.Drawing.Point(199, 109)
        Me.lblDistance.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblDistance.Name = "lblDistance"
        Me.lblDistance.Size = New System.Drawing.Size(86, 29)
        Me.lblDistance.TabIndex = 4
        Me.lblDistance.Text = "Label2"
        '
        'lblDestUTM
        '
        Me.lblDestUTM.AutoSize = True
        Me.lblDestUTM.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblDestUTM.Location = New System.Drawing.Point(588, 74)
        Me.lblDestUTM.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblDestUTM.Name = "lblDestUTM"
        Me.lblDestUTM.Size = New System.Drawing.Size(86, 29)
        Me.lblDestUTM.TabIndex = 5
        Me.lblDestUTM.Text = "Label3"
        '
        'lblSearchStatus
        '
        Me.lblSearchStatus.AutoSize = True
        Me.lblSearchStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblSearchStatus.Location = New System.Drawing.Point(863, 74)
        Me.lblSearchStatus.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblSearchStatus.Name = "lblSearchStatus"
        Me.lblSearchStatus.Size = New System.Drawing.Size(86, 29)
        Me.lblSearchStatus.TabIndex = 6
        Me.lblSearchStatus.Text = "Label4"
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(13, 142)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(947, 400)
        Me.TextBox2.TabIndex = 7
        '
        'lblMyPlace
        '
        Me.lblMyPlace.AutoSize = True
        Me.lblMyPlace.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblMyPlace.Location = New System.Drawing.Point(7, 5)
        Me.lblMyPlace.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblMyPlace.Name = "lblMyPlace"
        Me.lblMyPlace.Size = New System.Drawing.Size(86, 29)
        Me.lblMyPlace.TabIndex = 8
        Me.lblMyPlace.Text = "Label5"
        '
        'lblUTMY
        '
        Me.lblUTMY.AutoSize = True
        Me.lblUTMY.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblUTMY.Location = New System.Drawing.Point(391, 5)
        Me.lblUTMY.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblUTMY.Name = "lblUTMY"
        Me.lblUTMY.Size = New System.Drawing.Size(86, 29)
        Me.lblUTMY.TabIndex = 9
        Me.lblUTMY.Text = "Label6"
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblHeading.Location = New System.Drawing.Point(676, 5)
        Me.lblHeading.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(86, 29)
        Me.lblHeading.TabIndex = 10
        Me.lblHeading.Text = "Label7"
        '
        'Timer1
        '
        '
        'lblCompass
        '
        Me.lblCompass.AutoSize = True
        Me.lblCompass.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblCompass.Location = New System.Drawing.Point(830, 3)
        Me.lblCompass.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblCompass.Name = "lblCompass"
        Me.lblCompass.Size = New System.Drawing.Size(86, 29)
        Me.lblCompass.TabIndex = 11
        Me.lblCompass.Text = "Label8"
        '
        'lblTargetAngle
        '
        Me.lblTargetAngle.AutoSize = True
        Me.lblTargetAngle.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblTargetAngle.Location = New System.Drawing.Point(6, 109)
        Me.lblTargetAngle.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblTargetAngle.Name = "lblTargetAngle"
        Me.lblTargetAngle.Size = New System.Drawing.Size(86, 29)
        Me.lblTargetAngle.TabIndex = 12
        Me.lblTargetAngle.Text = "Label9"
        '
        'lblCurAngle
        '
        Me.lblCurAngle.AutoSize = True
        Me.lblCurAngle.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblCurAngle.Location = New System.Drawing.Point(493, 109)
        Me.lblCurAngle.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblCurAngle.Name = "lblCurAngle"
        Me.lblCurAngle.Size = New System.Drawing.Size(99, 29)
        Me.lblCurAngle.TabIndex = 13
        Me.lblCurAngle.Text = "Label10"
        '
        'lblFunctionKey
        '
        Me.lblFunctionKey.AutoSize = True
        Me.lblFunctionKey.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.lblFunctionKey.Location = New System.Drawing.Point(391, 37)
        Me.lblFunctionKey.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.lblFunctionKey.Name = "lblFunctionKey"
        Me.lblFunctionKey.Size = New System.Drawing.Size(497, 29)
        Me.lblFunctionKey.TabIndex = 14
        Me.lblFunctionKey.Text = "F8 : Set my QTH     F9 : Set Antenna Direction"
        '
        'DBFDataGrid
        '
        Me.DBFDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DBFDataGrid.Location = New System.Drawing.Point(14, 586)
        Me.DBFDataGrid.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.DBFDataGrid.Name = "DBFDataGrid"
        Me.DBFDataGrid.RowHeadersWidth = 51
        Me.DBFDataGrid.Size = New System.Drawing.Size(935, 279)
        Me.DBFDataGrid.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(199, 546)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(717, 24)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "Developer : E25VBE   Facebook: Pat Jojo Sadavongvivad or jojopat@gmail.com"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(963, 570)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblFunctionKey)
        Me.Controls.Add(Me.lblCurAngle)
        Me.Controls.Add(Me.lblTargetAngle)
        Me.Controls.Add(Me.lblCompass)
        Me.Controls.Add(Me.lblHeading)
        Me.Controls.Add(Me.lblUTMY)
        Me.Controls.Add(Me.lblMyPlace)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.lblSearchStatus)
        Me.Controls.Add(Me.lblDestUTM)
        Me.Controls.Add(Me.lblDistance)
        Me.Controls.Add(Me.lblDestination)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.DBFDataGrid)
        Me.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(222, Byte))
        Me.Margin = New System.Windows.Forms.Padding(5, 4, 5, 4)
        Me.Name = "Form1"
        Me.Text = "DADA 1.1 Directional Antenna Deployment Assistant    --    F8:Set  my QTH     F9:" &
    "Rotate Antenna "
        CType(Me.DBFDataGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents lblDestination As Label
    Friend WithEvents lblDistance As Label
    Friend WithEvents lblDestUTM As Label
    Friend WithEvents lblSearchStatus As Label
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents lblMyPlace As Label
    Friend WithEvents lblUTMY As Label
    Friend WithEvents lblHeading As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents lblCompass As Label
    Friend WithEvents lblTargetAngle As Label
    Friend WithEvents lblCurAngle As Label
    Friend WithEvents lblFunctionKey As Label
    Friend WithEvents DBFDataGrid As DataGridView
    Friend WithEvents Label1 As Label
End Class
